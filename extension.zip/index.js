// Configuration for each mode
const menuConfig = {
    Customize: [
        {
            type: 'message',
            id: 'menu_welcome',
            value: 'You are in Menu mode',
            size: 'medium',
            position: {
                x: 5,
                y: 25
            }
        },
        {
            type: 'color',
            id: 'menu_theme',
            caption: 'Select Menu theme color',
            value: '#28a745',
            size: 'medium',
            position: {
                x: 5,
                y: 35
            }
        },
        {
            type: 'hidden',
            id: 'mode',
            value: 'Menu'
        }
    ]
};

const kotConfig = {
    Customize: [
        {
            type: 'message',
            id: 'kot_welcome',
            value: 'You are in KOT mode',
            size: 'medium',
            position: {
                x: 5,
                y: 25
            }
        },
        {
            type: 'dropdown',
            id: 'kot_options',
            caption: 'Select KOT Type',
            list: ['Dine In', 'Take Away', 'Delivery'],
            value: ''
        },
        {
            type: 'hidden',
            id: 'mode',
            value: 'KOT'
        }
    ]
};

function createChannel() {
    const channel = $vxt.createChannel($vxtSubChannelId);

    channel.subscribe('get', (data) => {
        console.log("data = ", data);
        console.log("data.payload = ", data.payload);

        if (data.type === 'contents') {
            const payload = data.payload;
            let contentList = [];

            switch (payload.dropdownListModes) {
                case 'Menu':
                    contentList = [{
                        resourceType: 'CONTENT',
                        resourceId: '101',
                        resourceName: 'Menu Mode',
                        thumbnailPath: 'https://via.placeholder.com/300x200?text=Menu',
                        isLandscape: true,
                        category: 'Menu',
                        orientation: 'landscape',
                        keywords: 'carbon,menu',
                        config: { ...menuConfig }
                    }];
                    break;

                case 'KOT':
                    contentList = [{
                        resourceType: 'CONTENT',
                        resourceId: '102',
                        resourceName: 'KOT Mode',
                        thumbnailPath: 'https://via.placeholder.com/300x200?text=KOT',
                        isLandscape: true,
                        category: 'KOT',
                        orientation: 'landscape',
                        keywords: 'carbon,kot',
                        config: { ...kotConfig }
                    }];
                    break;

                default:
                    break;
            }

            channel.publish('data', {
                type: 'contents',
                payload: {
                    categories: [
                        { name: payload.dropdownListModes, displayMode: 'grid' }
                    ],
                    content: contentList
                }
            });

            console.log(`${payload.dropdownListModes} Content = `, contentList);
        }
    });
}

function waitForVxtApi() {
    const interval = setInterval(() => {
        if (window.$vxt) {
            clearInterval(interval);
            createChannel();
        }
    }, 100);
}

waitForVxtApi();
