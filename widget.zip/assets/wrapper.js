/**
 * PIRS Profile Wrapper Application
 * Profile: test
 * Built: 2025-06-27T06:26:55.415Z
 * Target: https://preview--carbonstreamline.lovable.app
 */

class PIRSProfileWrapper {
  constructor() {
    // Config baked in during build for profile: test
    this.config = {
  "app": {
    "name": "Xellar Test",
    "description": "Test build of Xellar PIRS wrapper",
    "version": "1.0.0-test"
  },
  "target": {
    "url": "https://preview--carbonstreamline.lovable.app",
    "name": "Test Environment",
    "timeout": 20000,
    "healthCheckInterval": 5000,
    "retryAttempts": 3
  },
  "ui": {
    "showHeader": true,
    "showDevInfo": true,
    "showUrl": true,
    "theme": "test"
  },
  "build": {
    "minify": false,
    "includeSourceMaps": true,
    "profile": "test",
    "timestamp": "2025-06-27T06:26:55.415Z"
  }
};
    
    this.targetUrl = this.config.target.url;
    this.retryCount = 0;
    this.loadTimeout = null;
    this.healthCheckInterval = null;
    
    this.init();
  }
  
  init() {
    console.log('[PIRS Wrapper] Initializing...');
    console.log('[PIRS Wrapper] Profile:', this.config.build.profile);
    console.log('[PIRS Wrapper] Target URL:', this.targetUrl);
    console.log('[PIRS Wrapper] App Name:', this.config.app.name);
    
    // Cache DOM elements
    this.iframe = document.getElementById('appIframe');
    this.container = document.getElementById('appContainer');
    this.statusDot = document.getElementById('statusDot');
    this.statusText = document.getElementById('statusText');
    this.errorMessage = document.getElementById('errorMessage');
    this.loadingDetail = document.getElementById('loadingDetail');
    this.profileBadge = document.getElementById('profileBadge');
    
    // Dev info elements
    this.devInfo = document.getElementById('devInfo');
    this.currentUrlSpan = document.getElementById('currentUrl');
    this.pirsModeSpan = document.getElementById('pirsMode');
    this.profileSpan = document.getElementById('profile');
    
    this.detectEnvironment();
    this.setupEventListeners();
    this.loadTargetApp();
  }
  
  detectEnvironment() {
    const isPIRS = window.location.protocol === 'file:' || 
                   window !== window.top ||
                   navigator.userAgent.includes('Samsung') ||
                   navigator.userAgent.includes('VXT');
    
    // Update dev info
    if (this.pirsModeSpan) this.pirsModeSpan.textContent = isPIRS ? 'Yes' : 'No';
    if (this.profileSpan) this.profileSpan.textContent = this.config.build.profile;
    if (this.currentUrlSpan) this.currentUrlSpan.textContent = this.targetUrl;
    
    // Update profile badge
    if (this.profileBadge) {
      this.profileBadge.textContent = this.config.build.profile.toUpperCase();
      this.profileBadge.className = `profile-badge profile-${this.config.build.profile}`;
    }
    
    if (isPIRS) {
      console.log('🎯 Running in PIRS environment');
      document.body.classList.add('pirs-mode');
    }
    
    // Apply UI configuration from profile
    if (!this.config.ui.showHeader) {
      document.body.classList.add('minimal-mode');
    }
    
    if (!this.config.ui.showDevInfo) {
      document.body.classList.add('hide-dev-info');
    }
  }
  
  setupEventListeners() {
    window.addEventListener('message', this.handleAppMessage.bind(this));
    window.addEventListener('online', this.handleNetworkOnline.bind(this));
    window.addEventListener('offline', this.handleNetworkOffline.bind(this));
  }
  
  async loadTargetApp() {
    console.log(`[PIRS Wrapper] Loading target: ${this.targetUrl}`);
    this.updateStatus('Connecting...', 'loading');
    this.updateLoadingDetail(`Connecting to ${this.config.target.name}...`);
    
    // Validate URL format
    try {
      new URL(this.targetUrl);
    } catch (e) {
      this.handleLoadError(`Invalid target URL: ${this.targetUrl}`);
      return;
    }
    
    this.loadApp(this.targetUrl);
  }
  
  loadApp(url) {
    console.log(`[PIRS Wrapper] Loading app: ${url}`);
    this.updateStatus('Connecting...', 'loading');
    this.updateLoadingDetail(`Loading ${this.config.target.name}...`);
    
    this.container.classList.remove('loaded', 'error');
    this.iframe.src = url;
    
    this.loadTimeout = setTimeout(() => {
      this.handleLoadError('Connection timeout - application did not load within the expected time');
    }, this.config.target.timeout);
    
    this.iframe.onload = () => {
      clearTimeout(this.loadTimeout);
      this.handleLoadSuccess();
    };
    
    this.iframe.onerror = () => {
      clearTimeout(this.loadTimeout);
      this.handleLoadError('Failed to load application');
    };
    
    this.startHealthCheck();
  }
  
  handleLoadSuccess() {
    console.log('[PIRS Wrapper] App loaded successfully');
    this.container.classList.add('loaded');
    this.updateStatus(`Connected (${this.config.build.profile})`, 'connected');
    this.retryCount = 0;
    
    setTimeout(() => {
      this.sendPIRSContext();
    }, 1000);
  }
  
  handleLoadError(message) {
    console.log('[PIRS Wrapper] Load failed:', message);
    this.container.classList.add('error');
    this.updateStatus('Connection Failed', 'disconnected');
    
    let errorMsg = message || `Unable to connect to ${this.config.target.name}`;
    
    // Add profile-specific error guidance
    if (this.config.build.profile === 'development') {
      errorMsg += `\n\n🔧 Development Mode:\nMake sure your development server is running at ${this.targetUrl}`;
    } else if (this.config.build.profile === 'production') {
      errorMsg += `\n\n🚀 Production Mode:\nCheck if the application is deployed and accessible.`;
    } else if (this.config.build.profile === 'test') {
      errorMsg += `\n\n🧪 Test Mode:\nVerify the test environment is available.`;
    }
    
    this.errorMessage.textContent = errorMsg;
    this.stopHealthCheck();
  }
  
  retryConnection() {
    this.retryCount++;
    console.log(`[PIRS Wrapper] Retry ${this.retryCount}/${this.config.target.retryAttempts}`);
    
    if (this.retryCount <= this.config.target.retryAttempts) {
      this.loadApp(this.targetUrl);
    } else {
      this.handleLoadError(`Failed after ${this.config.target.retryAttempts} attempts. Please check the target application.`);
    }
  }
  
  updateStatus(message, type) {
    if (this.statusText) {
      this.statusText.textContent = message;
    }
    
    if (this.statusDot) {
      this.statusDot.className = 'status-dot';
      if (type === 'connected') this.statusDot.classList.add('connected');
      else if (type === 'loading') this.statusDot.classList.add('loading');
    }
  }
  
  updateLoadingDetail(message) {
    if (this.loadingDetail) {
      this.loadingDetail.textContent = message;
    }
  }
  
  sendPIRSContext() {
    const context = {
      type: 'pirs-context',
      isPIRS: document.body.classList.contains('pirs-mode'),
      isLocalhost: this.targetUrl.includes('localhost'),
      wrapper: 'pirs-profile-wrapper',
      profile: this.config.build.profile,
      config: this.config,
      timestamp: Date.now()
    };
    
    try {
      this.iframe.contentWindow.postMessage(context, this.targetUrl);
      console.log('[PIRS Wrapper] Sent context to target app');
    } catch (e) {
      console.log('[PIRS Wrapper] Could not send context (CORS expected)');
    }
  }
  
  handleAppMessage(event) {
    try {
      const targetOrigin = new URL(this.targetUrl).origin;
      if (!event.origin.includes(targetOrigin.replace(/^https?:\/\//, ''))) {
        return;
      }
    } catch (e) {
      return;
    }
    
    console.log('[PIRS Wrapper] Message from app:', event.data);
    
    switch (event.data.type) {
      case 'app-ready':
        this.updateStatus(`Ready (${this.config.build.profile})`, 'connected');
        break;
      case 'request-reload':
        this.loadApp(this.targetUrl);
        break;
      case 'health-check':
        this.updateStatus(`Connected (${this.config.build.profile})`, 'connected');
        break;
    }
  }
  
  startHealthCheck() {
    this.stopHealthCheck();
    
    this.healthCheckInterval = setInterval(() => {
      try {
        this.iframe.contentWindow.postMessage({
          type: 'health-ping',
          profile: this.config.build.profile
        }, this.targetUrl);
      } catch (e) {
        this.handleLoadError('Connection lost');
      }
    }, this.config.target.healthCheckInterval);
  }
  
  stopHealthCheck() {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }
  
  handleNetworkOnline() {
    if (this.container.classList.contains('error')) {
      setTimeout(() => this.loadApp(this.targetUrl), 1000);
    }
  }
  
  handleNetworkOffline() {
    this.updateStatus('Network Offline', 'disconnected');
  }
}

// Global retry function
function retryConnection() {
  if (window.pirsWrapper) {
    window.pirsWrapper.retryConnection();
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  window.pirsWrapper = new PIRSProfileWrapper();
});

console.log('[PIRS Wrapper] Profile-based wrapper loaded for: test');