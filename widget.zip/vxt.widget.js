function createChannel() {
    const channel = $vxt.createChannel($vxtSubChannelId);
    channel.subscribe('config', (payload) => { console.log(payload.data); init(payload); });
    channel.subscribe('playstate', (payload) => console.log(payload.type));
    channel.subscribe('vxtstate', (payload) => console.log(payload.type));
    console.log('[WiNE API] channel created', $vxtSubChannelId);
}
function waitForVxtApi(callback) {
    const interval = setInterval(() => {
        if (window.$vxt) {
            clearInterval(interval);
            createChannel();
        }
    }, 100)
} waitForVxtApi();